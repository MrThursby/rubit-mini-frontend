<template>
  <div class="container mx-auto px-4">
    <slot />
  </div>
</template>

<script>
export default {
  name: "Container"
}
</script>

<style scoped>

</style>
